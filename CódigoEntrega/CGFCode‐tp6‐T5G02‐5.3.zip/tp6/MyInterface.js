/**
 * MyInterface
 * @constructor
 */
 
function MyInterface()
{
	CGFinterface.call(this);
};

MyInterface.prototype = Object.create(CGFinterface.prototype);
MyInterface.prototype.constructor = MyInterface;

/**
 * init
 * @param {CGFapplication} application
 */

MyInterface.prototype.init = function(application)
{
	CGFinterface.prototype.init.call(this, application);
	
	// init GUI. For more information on the methods, check:
	//  http://workshop.chromeexperiments.com/examples/gui
	
	this.gui = new dat.GUI();
	this.gui.add(this.scene, 'Pausa');	
	
	var group = this.gui.addFolder("Luzes");
	group.open();
	group.add(this.scene, 'luz1');
	group.add(this.scene, 'luz2');
	group.add(this.scene, 'luz3');
	group.add(this.scene, 'luz4');
	group.add(this.scene, 'luz5');
	
	this.gui.add(this.scene, 'AparenciaDrone', { MetalizadoFrente: 0, Metalizado: 1, Azul: 2, Vermelho: 3, Verde: 4, Preto: 5});
	
	this.gui.add(this.scene, 'speed', 0.1, 2.0);

	return true;
};

/**
 * processKeyboard
 * @param event {Event}
 */

MyInterface.prototype.processKeyDown = function(event)
{
	 CGFinterface.prototype.processKeyDown.call(this,event);
	 
	 switch (event.keyCode)
	 {
	 	case (87): // 'W'
	 	case (119): // 'w'
	 	{
	 		this.scene.drone.movementSpeed = 5;
	 		this.scene.drone.movingFront = true;
	 		break;
	 	}
	 	
		case (83): // 'S'
		case (115): // 's'
		{
			this.scene.drone.movementSpeed = 5;
			this.scene.drone.movingBack = true;
			break;
		}
		
		case (65): // 'A'
		case (97): // 'a'
		{
			this.scene.drone.rotatingLeft = true;
			break;
		}

		case (68): // 'D'
		case (100): // 'd'
		{
			this.scene.drone.rotatingRight = true;
			break;
		}
		
		case (73): // 'I'
		case (105): // 'i'
		{
			this.scene.drone.goingUp = true;
			break;
		}
		
		case (74): // 'J'
		case (106): // 'j'
		{
			this.scene.drone.goingDown = true;
			break;
		}
	 }
};

MyInterface.prototype.processKeyUp = function(event)
{
	 CGFinterface.prototype.processKeyUp.call(this,event);
	 
	 switch (event.keyCode)
	 {
	 	case (87): // 'W'
	 	case (119): // 'w'
	 	{
	 		this.scene.drone.movingFront = false;
	 		break;
	 	}
	 	
		case (83): // 'S'
		case (115): // 's'
		{
			this.scene.drone.movingBack = false;
			break;
		}
		
		case (65): // 'A'
		case (97): // 'a'
		{
			this.scene.drone.rotatingLeft = false;
			break;
		}

		case (68): // 'D'
		case (100): // 'd'
		{
			this.scene.drone.rotatingRight = false;
			break;
		}
		
		case (73): // 'I'
		case (105): // 'i'
		{
			this.scene.drone.goingUp = false;
			this.scene.drone.moveUp(0.1);
			break;
		}
		
		case (74): // 'J'
		case (106): // 'j'
		{
			this.scene.drone.goingDown = false;
			break;
		}
	 }
};

/*
MyInterface.prototype.processKeyboard = function(event)
{
	CGFinterface.prototype.processKeyboard.call(this,event);
	
	// Check key codes e.g. here: http://www.asciitable.com/
	// or use String.fromCharCode(event.keyCode) to compare chars
	// for better cross-browser support, you may also check suggestions on using event.which in http://www.w3schools.com/jsref/event_key_keycode.asp
	
	switch (event.keyCode)
	{
		case (65): // 'A'
		case (97): // 'a'
		{
			console.log("Key 'A' pressed");
			this.scene.drone.setAngle(5);
			break;
		}

		case (68): // 'D'
		case (100): // 'd'
		{
			console.log("Key 'D' pressed");
			this.scene.drone.setAngle(-5);
			break;
		}
		
		case (87): // 'W'
		case (119): // 'w'
		{
			console.log("Key 'W' pressed");
			this.scene.drone.moveForward(0.1);
			break;
		}
		
		case (83): // 'S'
		case (115): // 's'
		{
			console.log("Key 'S' pressed");
			this.scene.drone.moveForward(-0.1);
			break;
		}
		
		case (73): // 'I'
		case (105): // 'i'
		{
			console.log("Key 'I' pressed");
			this.scene.drone.moveUp(0.1);
			break;
		}
		
		case (74): // 'J'
		case (106): // 'j'
		{
			console.log("Key 'J' pressed");
			this.scene.drone.moveUp(-0.1);
			break;
		}
	};
};
*/
