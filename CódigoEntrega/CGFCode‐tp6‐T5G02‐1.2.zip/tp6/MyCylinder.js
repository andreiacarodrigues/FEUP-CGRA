/**
 * MyCylinder
 * @constructor
 */
 function MyCylinder(scene, slices, stacks) {
 	CGFobject.call(this,scene);
	
	this.slices = slices;
	this.stacks = stacks;

 	this.initBuffers();
 };

 MyCylinder.prototype = Object.create(CGFobject.prototype);
 MyCylinder.prototype.constructor = MyCylinder;

 MyCylinder.prototype.initBuffers = function()
 {
 	this.vertices = [];

 	this.indices = [];

 	this.normals = [];
 	
 	var ang = 0;
 	var angAux = (2*Math.PI)/this.slices;
 	
 	var x = 1;
 	
 	for(var i = 0; i < this.stacks + 1; i++)
 	{
 		for(var j = 0; j < this.slices; j++)
 		{
 			this.vertices.push(Math.cos(ang), Math.sin(ang), x);
 			this.normals.push(Math.cos(ang), Math.sin(ang), 0);
 			
 			ang = ang + angAux;
 		}
 		ang = 0;
 		x = x-(1/(this.stacks));
 	}
 	
 	var start = 0;
 	
 	for(var i = 0; i < this.stacks; i++)
 	{
 		for(var j = 0; j < this.slices; j++)
 	 	{
 			start = j + i * this.slices;
 			
 			if(j != this.slices-1)
 			{
 				this.indices.push(start+this.slices+1, start, start + this.slices);
 				this.indices.push(start+1, start, start + this.slices+1);
 			}
 			else
 			{
 				startAux = i * this.slices;
 				this.indices.push(startAux+this.slices, start, start + this.slices);
 				this.indices.push(startAux, start, startAux + this.slices);
 			}
 	 	}
 	}
 	
 	
 	this.primitiveType = this.scene.gl.TRIANGLES;
 	this.initGLBuffers();
 };
 

