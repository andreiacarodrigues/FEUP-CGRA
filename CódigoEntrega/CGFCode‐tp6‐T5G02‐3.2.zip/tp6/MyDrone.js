 	/**
 * MyDrone
 * @constructor
 */
 function MyDrone(scene)
 {
 	CGFobject.call(this,scene);
 	this.angle = 0;
 	this.yOffset = 0;
 	this.xOffset = 0;
 	this.zOffset = 0;
 	this.initBuffers();
 };

 MyDrone.prototype = Object.create(CGFobject.prototype);
 MyDrone.prototype.constructor = MyDrone;

 MyDrone.prototype.initBuffers = function()
 {
	this.vertices =
	[
	0.5, 0.3, 0,
	-0.5, 0.3, 0,
	0, 0.3, 2      
	];

	this.indices =
	[ 2, 0, 1 ];
	
 	this.normals =
 	[
	0,1,0,
	0,1,0,
	0,1,0
	];

 	this.primitiveType = this.scene.gl.TRIANGLES;
 	this.initGLBuffers();
 };
 
 
 MyDrone.prototype.setAngle = function(angle)
 {
	 this.angle = this.angle + angle;
 };
 
 MyDrone.prototype.moveUp = function(y)
 {
	 this.yOffset = this.yOffset + y;
 };
 
 MyDrone.prototype.moveForward = function(z)
 {
	 this.xOffset = this.xOffset + (z*Math.sin(this.angle * degToRad));
	 this.zOffset = this.zOffset + (z*Math.cos(this.angle * degToRad));
 };
 
 
 MyDrone.prototype.display = function()
 {
	 
	 this.scene.pushMatrix();
		this.scene.translate(this.xOffset, this.yOffset, this.zOffset);
	 	this.scene.rotate(this.angle * degToRad,0,1,0);
	 	this.drawElements(this.primitiveType);
	 this.scene.popMatrix();
 };
