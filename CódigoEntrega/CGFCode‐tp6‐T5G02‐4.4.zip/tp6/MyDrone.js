 	/**
 * MyDrone
 * @constructor
 */
 function MyDrone(scene)
 {
 	CGFobject.call(this,scene);
 	
 	/* Movement variables */
 	this.angle = 0;
 	this.yOffset = 0;
 	this.xOffset = 0;
 	this.zOffset = 0;
 	
 	/* Drone construction variables */
	this.cylinder = new MyCylinderWithTops(this.scene, 20, 8);
	this.sphere = new MySemiSphere(this.scene, 20, 20);
	this.curve = new MyCurve(this.scene);
	this.cube = new MyUnitCubeQuad(this.scene);
	
	//Cilindros do Meio; Cilindros Pontas; Centro; H�lices; Pernas
	
	this.appCilindrosMeio = new CGFappearance(this);
	this.appCilindrosHelices = new CGFappearance(this);
	this.appSemiesferaCentral = new CGFappearance(this);
	this.appHelices = new CGFappearance(this);
	this.appPernas = new CGFappearance(this);
	
 	this.initBuffers();
 };

 MyDrone.prototype = Object.create(CGFobject.prototype);
 MyDrone.prototype.constructor = MyDrone;
 
 /* Rotation */
 MyDrone.prototype.setAngle = function(angle)
 {
	 this.angle = this.angle + angle;
 };
 
 MyDrone.prototype.moveUp = function(y)
 {
	 this.yOffset = this.yOffset + y;
 };
 
 MyDrone.prototype.moveForward = function(z)
 {
	 this.xOffset = this.xOffset + (z*Math.sin(this.angle * degToRad));
	 this.zOffset = this.zOffset + (z*Math.cos(this.angle * degToRad));
 };
 
 MyDrone.prototype.updateAppearance = function(appearanceNumber)
 {
	 this.appCilindrosMeio = this.scene.droneAppearanceList[appearanceNumber][0];
	 this.appCilindrosHelices = this.scene.droneAppearanceList[appearanceNumber][1];
	 this.appSemiesferaCentral = this.scene.droneAppearanceList[appearanceNumber][2];
	 this.appHelices = this.scene.droneAppearanceList[appearanceNumber][3];
	 this.appPernas = this.scene.droneAppearanceList[appearanceNumber][4];
 };
 
 MyDrone.prototype.buildDrone = function()
 {
	var deg2rad=Math.PI/180.0;
	 	
	this.appCilindrosMeio.apply();
	
	// Cilindro 1 base - no eixo zz
	this.scene.pushMatrix();
	this.scene.translate(0,0,2.5);
	this.scene.scale(1/8, 1/8, 5);
	this.cylinder.display();
	this.scene.popMatrix();

	// Cilindro 2 base - no eixo xx
	this.scene.pushMatrix();
	this.scene.translate(2.5,0,0);
	this.scene.rotate(deg2rad * 90, 0, 1, 0);
	this.scene.scale(1/8, 1/8, 5);
	this.cylinder.display();
	this.scene.popMatrix();
	
	
	this.appCilindrosHelices.apply();
	
	// Cilindro 1 Helices - Sentido negativo eixo zz
	this.scene.pushMatrix();
	this.scene.translate(0,-1/6,-2.5);
	this.scene.rotate(deg2rad * 90, 1, 0, 0);
	this.scene.scale(1/4, 1/4, 1/3);
	this.cylinder.display();
	this.scene.popMatrix();
	 	
	// Esfera 1 Helices - Sentido negativo eixo zz
	this.scene.pushMatrix();
	this.scene.translate(0,1/5-0.1,-2.5);
	this.scene.scale(1/4,1/4,1/4);
	this.scene.rotate(-deg2rad * 90, 1, 0, 0);
	this.sphere.display();
	this.scene.popMatrix();
	
	// Cilindro 2 Helices - Sentido positivo eixo zz
	this.scene.pushMatrix();
	this.scene.translate(0,-1/6,2.5);
	this.scene.rotate(deg2rad * 90, 1, 0, 0);
	this.scene.scale(1/4, 1/4, 1/3);
	this.cylinder.display();
	this.scene.popMatrix();
	
	// Esfera 2 Helices - Sentido positivo eixo zz
	this.scene.pushMatrix();
	this.scene.translate(0,1/5-0.1,2.5);
	this.scene.scale(1/4,1/4,1/4);
	this.scene.rotate(-deg2rad * 90, 1, 0, 0);
	this.sphere.display();
	this.scene.popMatrix();
	
	// Cilindro 3 Helices - Sentido positivo eixo xx
	this.scene.pushMatrix();
	this.scene.translate(2.5,-1/6,0);
	this.scene.rotate(deg2rad * 90, 1, 0, 0);
	this.scene.scale(1/4, 1/4, 1/3);
	this.cylinder.display();
	this.scene.popMatrix();
	
	// Esfera 3 Helices - Sentido positivo eixo xx
	this.scene.pushMatrix();
	this.scene.translate(2.5,1/5-0.1,0);
	this.scene.scale(1/4,1/4,1/4);
	this.scene.rotate(-deg2rad * 90, 1, 0, 0);
	this.sphere.display();
	this.scene.popMatrix();
	
	 // Cilindro 4 Helices - Sentido negativo eixo xx
	this.scene.pushMatrix();
	this.scene.translate(-2.5,-1/6,0);
	this.scene.rotate(deg2rad * 90, 1, 0, 0);
	this.scene.scale(1/4, 1/4, 1/3);
	this.cylinder.display();
	this.scene.popMatrix();
	
	// Esfera  4 Helices - Sentido negativo eixo xx
	this.scene.pushMatrix();
	this.scene.translate(-2.5,1/5-0.1,0);
	this.scene.scale(1/4,1/4,1/4);
	this.scene.rotate(-deg2rad * 90, 1, 0, 0);
	this.sphere.display();
	this.scene.popMatrix();
	
	this.appHelices.apply();
	
	// Helices 1 - Sentido negativo eixo zz
	this.scene.pushMatrix();
	this.scene.translate(1.1,0,-2.5);
	this.scene.rotate(deg2rad * 90, 0, 1, 0);
	this.scene.scale(1/6, 1/22, 2.2);
	this.cylinder.display();
	this.scene.popMatrix();
	
	// Helices 2 - Sentido positivo eixo zz
	this.scene.pushMatrix();
	this.scene.translate(1.1,0,2.5);
	this.scene.rotate(deg2rad * 90, 0, 1, 0);
	this.scene.scale(1/6, 1/22, 2.2);
	this.cylinder.display();
	this.scene.popMatrix();
	 	
	// Helices 3 - Sentido positivo eixo xx
	this.scene.pushMatrix();
	this.scene.translate(2.5,0,1.1);
	this.scene.scale(1/6, 1/22, 2.2);
	this.cylinder.display();
	this.scene.popMatrix();
	 	
	// Helices 4 - Sentido negativo eixo xx
	this.scene.pushMatrix();
	this.scene.translate(-2.5,0,1.1);
	this.scene.scale(1/6, 1/22, 2.2);
	this.cylinder.display();
	this.scene.popMatrix();
	 	
	this.appSemiesferaCentral.apply();
	
	// Esfera Central
	this.scene.pushMatrix();
	this.scene.translate(0,-0.15,0);
	this.scene.rotate(deg2rad * 90, 0, 1, 0); // para a appearance ficar no sitio certo
	this.scene.rotate(-deg2rad * 90, 1, 0, 0);
	this.sphere.display();
	this.scene.popMatrix();
	 
	this.appPernas.apply();
	
	// Parab�lica lado frente esquerda
	this.scene.pushMatrix();
	this.scene.translate(1.55,-1.65,0.5);
	this.scene.rotate(-deg2rad * 90, 0, 1, 0);
	this.scene.scale(0.13, 3, 3);
	this.curve.display();
	this.scene.popMatrix();
	 	
	// Parab�lica lado tr�s direita
	this.scene.pushMatrix();
	this.scene.translate(1.55,-1.65,-0.5);
	this.scene.rotate(-deg2rad * 90, 0, 1, 0);
	this.scene.scale(0.13, 3, 3);
	this.curve.display();
	this.scene.popMatrix();
	 	
	// Base lado frente 
	this.scene.pushMatrix();
	this.scene.translate(1.55,-1.65,0);
	this.scene.scale(0.1, 0.1, 3);
	this.cube.display();
	this.scene.popMatrix();
	
	// Parab�lica lado frente esquerda
	this.scene.pushMatrix();
	this.scene.translate(-1.55,-1.65,0.5);
	this.scene.rotate(deg2rad * 90, 0, 1, 0);
	this.scene.scale(0.13, 3, 3);
	this.curve.display();
	this.scene.popMatrix();
	 	
	// Parab�lica lado tr�s esquerda
	this.scene.pushMatrix();
	this.scene.translate(-1.55,-1.65,-0.5);
	this.scene.rotate(deg2rad * 90, 0, 1, 0);
	this.scene.scale(0.13, 3, 3);
	this.curve.display();
	this.scene.popMatrix();
	 	
	// Base lado tr�s 
	this.scene.pushMatrix();
	this.scene.translate(-1.55,-1.65,0);
	this.scene.scale(0.1, 0.1, 3);
	this.cube.display();
	this.scene.popMatrix();
 };
 
 
 MyDrone.prototype.display = function()
 {
	 this.scene.pushMatrix();
		this.scene.translate(this.xOffset, this.yOffset, this.zOffset);
	 	this.scene.rotate(this.angle * degToRad,0,1,0);
	 	this.buildDrone();
	 this.scene.popMatrix();
 };
