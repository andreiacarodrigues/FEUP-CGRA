var degToRad = Math.PI / 180.0;
var BOARD_WIDTH = 6.0;
var BOARD_HEIGHT = 4.0;
var BOARD_RATIO = BOARD_WIDTH / BOARD_HEIGHT;
var BOARD_A_DIVISIONS = 30;
var BOARD_B_DIVISIONS = 100;

function LightingScene()
{
	CGFscene.call(this);
}

LightingScene.prototype = Object.create(CGFscene.prototype);
LightingScene.prototype.constructor = LightingScene;

LightingScene.prototype.init = function(application)
{
	CGFscene.prototype.init.call(this, application);

	this.initCameras();

	this.initLights();
	
	this.enableTextures(true);

	this.gl.clearColor(0.0, 0.0, 0.0, 1.0);
	this.gl.clearDepth(100.0);
	this.gl.enable(this.gl.DEPTH_TEST);
	this.gl.enable(this.gl.CULL_FACE);
	this.gl.depthFunc(this.gl.LEQUAL);

	this.axis = new CGFaxis(this);

	this.table = new MyTable(this,0,1,0,1);
	this.wall = new Plane(this);
	this.leftWall = new MyQuad(this, -0.5,1.5,-0.5,1.5);
	this.floor = new MyQuad(this, 0, 10, 0, 12);
	
	this.boardA = new Plane(this, BOARD_A_DIVISIONS, BOARD_RATIO);
	this.boardB = new Plane(this, BOARD_B_DIVISIONS, BOARD_RATIO);
	
	// Sphere
	this.sphere = new MySemiSphere(this, 16, 4);
	
	// Clock
	this.clock = new MyClock(this, 8, 2);
	
	// Drone
	this.drone = new MyDrone(this);
	this.newDrone = new MyNewDrone(this);
	
	this.curve = new MyCurve(this);
	this.inversecurve = new MyInverseCurve(this);

	// Materials
	this.materialDefault = new CGFappearance(this);
	
	this.materialA = new CGFappearance(this);
	this.materialA.setAmbient(0.3,0.3,0.3,1);
	this.materialA.setDiffuse(0.6,0.6,0.6,1);
	this.materialA.setSpecular(0,0.2,0.8,1);	
	this.materialA.setShininess(120);

	this.materialB = new CGFappearance(this);
	this.materialB.setAmbient(0.3,0.3,0.3,1);
	this.materialB.setDiffuse(0.6,0.6,0.6,1);
	this.materialB.setSpecular(0.8,0.8,0.8,1);	
	this.materialB.setShininess(120);
	
	this.tableAppearance = new CGFappearance(this);
	this.tableAppearance.setAmbient(0.3,0.3,0.3,1);
	this.tableAppearance.setDiffuse(0.8,0.8,0.8,1);
	this.tableAppearance.setSpecular(0.1,0.1,0.1,1);	
	this.tableAppearance.setShininess(20);
	this.tableAppearance.loadTexture("../resources/images/table.png");
	
	this.floorAppearance = new CGFappearance(this);
	this.floorAppearance.setAmbient(0.3,0.3,0.3,1);
	this.floorAppearance.setDiffuse(0.8,0.8,0.8,1);
	this.floorAppearance.setSpecular(0.1,0.1,0.1,1);	
	this.floorAppearance.setShininess(20);
	this.floorAppearance.loadTexture("../resources/images/floor.png");
	
	this.windowAppearance = new CGFappearance(this);
	this.windowAppearance.setAmbient(0.3,0.3,0.3,1);
	this.windowAppearance.setDiffuse(0.8,0.8,0.8,1);
	this.windowAppearance.setSpecular(0.1,0.1,0.1,1);	
	this.windowAppearance.setShininess(20);
	this.windowAppearance.loadTexture("../resources/images/window.png");
	this.windowAppearance.setTextureWrap("CLAMP_TO_EDGE", "CLAMP_TO_EDGE");
	
	this.slidesAppearance = new CGFappearance(this);
	this.slidesAppearance.setAmbient(0.3,0.3,0.3,1);
	this.slidesAppearance.setDiffuse(0.8,0.8,0.8,1);
	this.slidesAppearance.setSpecular(0.1,0.1,0.1,1);	
	this.slidesAppearance.setShininess(20);
	this.slidesAppearance.loadTexture("../resources/images/slides.png");
	this.slidesAppearance.setTextureWrap("CLAMP_TO_EDGE", "CLAMP_TO_EDGE");
	
	this.boardAppearance = new CGFappearance(this);
	this.boardAppearance.setAmbient(0.3,0.3,0.3,1);
	this.boardAppearance.setSpecular(0.1,0.1,0.1,1);
	this.boardAppearance.setSpecular(0.5,0.5,0.5,1);	
	this.boardAppearance.setShininess(100);
	this.boardAppearance.loadTexture("../resources/images/board.png");
	this.boardAppearance.setTextureWrap("CLAMP_TO_EDGE", "CLAMP_TO_EDGE");
	
	this.clockAppearance = new CGFappearance(this);
	this.clockAppearance.setAmbient(0.3,0.3,0.3,1);
	this.clockAppearance.setSpecular(0.1,0.1,0.1,1);
	this.clockAppearance.setSpecular(0.5,0.5,0.5,1);	
	this.clockAppearance.setShininess(100);
	this.clockAppearance.loadTexture("../resources/images/clock.png");
	
	this.bottomBlackDroneAppearance = new CGFappearance(this);
	this.bottomBlackDroneAppearance.setAmbient(0.3,0.3,0.3,1);
	this.bottomBlackDroneAppearance.setSpecular(0.1,0.1,0.1,1);
	this.bottomBlackDroneAppearance.setSpecular(0.5,0.5,0.5,1);	
	this.bottomBlackDroneAppearance.setShininess(100);
	this.bottomBlackDroneAppearance.loadTexture("../resources/images/bottom.jpg");
	
	this.lightMetalDroneAppearance = new CGFappearance(this);
	this.lightMetalDroneAppearance.setAmbient(0.3,0.3,0.3,1);
	this.lightMetalDroneAppearance.setSpecular(0.1,0.1,0.1,1);
	this.lightMetalDroneAppearance.setSpecular(0.5,0.5,0.5,1);	
	this.lightMetalDroneAppearance.setShininess(100);
	this.lightMetalDroneAppearance.loadTexture("../resources/images/lightMetal.jpg");
	
	this.lightMetalWithFrontDroneAppearance = new CGFappearance(this);
	this.lightMetalWithFrontDroneAppearance.setAmbient(0.3,0.3,0.3,1);
	this.lightMetalWithFrontDroneAppearance.setSpecular(0.1,0.1,0.1,1);
	this.lightMetalWithFrontDroneAppearance.setSpecular(0.5,0.5,0.5,1);	
	this.lightMetalWithFrontDroneAppearance.setShininess(100);
	this.lightMetalWithFrontDroneAppearance.loadTexture("../resources/images/lightMetalWithWindow.jpg");
	
	this.darkMetalDroneAppearance = new CGFappearance(this);
	this.darkMetalDroneAppearance.setAmbient(0.3,0.3,0.3,1);
	this.darkMetalDroneAppearance.setSpecular(0.1,0.1,0.1,1);
	this.darkMetalDroneAppearance.setSpecular(0.5,0.5,0.5,1);	
	this.darkMetalDroneAppearance.setShininess(100);
	this.darkMetalDroneAppearance.loadTexture("../resources/images/darkMetal.jpg");
	
	this.lightBlueMetalDroneAppearance = new CGFappearance(this);
	this.lightBlueMetalDroneAppearance.setAmbient(0.3,0.3,0.3,1);
	this.lightBlueMetalDroneAppearance.setSpecular(0.1,0.1,0.1,1);
	this.lightBlueMetalDroneAppearance.setSpecular(0.5,0.5,0.5,1);	
	this.lightBlueMetalDroneAppearance.setShininess(100);
	this.lightBlueMetalDroneAppearance.loadTexture("../resources/images/lightBlue.jpg");
	
	this.darkBlueMetalDroneAppearance = new CGFappearance(this);
	this.darkBlueMetalDroneAppearance.setAmbient(0.3,0.3,0.3,1);
	this.darkBlueMetalDroneAppearance.setSpecular(0.1,0.1,0.1,1);
	this.darkBlueMetalDroneAppearance.setSpecular(0.5,0.5,0.5,1);	
	this.darkBlueMetalDroneAppearance.setShininess(100);
	this.darkBlueMetalDroneAppearance.loadTexture("../resources/images/darkBlue.jpg");
	
	this.redMetalDroneAppearance = new CGFappearance(this);
	this.redMetalDroneAppearance.setAmbient(0.3,0.3,0.3,1);
	this.redMetalDroneAppearance.setSpecular(0.1,0.1,0.1,1);
	this.redMetalDroneAppearance.setSpecular(0.5,0.5,0.5,1);	
	this.redMetalDroneAppearance.setShininess(100);
	this.redMetalDroneAppearance.loadTexture("../resources/images/redMetal.png");
	
	this.whiteMetalDroneAppearance = new CGFappearance(this);
	this.whiteMetalDroneAppearance.setAmbient(0.3,0.3,0.3,1);
	this.whiteMetalDroneAppearance.setSpecular(0.1,0.1,0.1,1);
	this.whiteMetalDroneAppearance.setSpecular(0.5,0.5,0.5,1);	
	this.whiteMetalDroneAppearance.setShininess(100);
	this.whiteMetalDroneAppearance.loadTexture("../resources/images/whiteMetal.jpg");
	
	this.greenTextureDroneAppearance = new CGFappearance(this);
	this.greenTextureDroneAppearance.setAmbient(0.3,0.3,0.3,1);
	this.greenTextureDroneAppearance.setSpecular(0.1,0.1,0.1,1);
	this.greenTextureDroneAppearance.setSpecular(0.5,0.5,0.5,1);	
	this.greenTextureDroneAppearance.setShininess(100);
	this.greenTextureDroneAppearance.loadTexture("../resources/images/greenTexture.png");
	
	this.greyTextureDroneAppearance = new CGFappearance(this);
	this.greyTextureDroneAppearance.setAmbient(0.3,0.3,0.3,1);
	this.greyTextureDroneAppearance.setSpecular(0.1,0.1,0.1,1);
	this.greyTextureDroneAppearance.setSpecular(0.5,0.5,0.5,1);	
	this.greyTextureDroneAppearance.setShininess(100);
	this.greyTextureDroneAppearance.loadTexture("../resources/images/greyTexture.png");
	
	this.blackDroneAppearance = new CGFappearance(this);
	this.blackDroneAppearance.setAmbient(0.3,0.3,0.3,1);
	this.blackDroneAppearance.setSpecular(0.1,0.1,0.1,1);
	this.blackDroneAppearance.setSpecular(0.5,0.5,0.5,1);	
	this.blackDroneAppearance.setShininess(100);
	this.blackDroneAppearance.loadTexture("../resources/images/blackTexture.jpg");
	
	
	//---------------------------------------------------------------------------------
	
	// Clock
	this.setUpdatePeriod(100);

	// GUI
	this.luz1 = true;
	this.luz2 = true;
	this.luz3 = true;
	this.luz4 = true;
	this.luz5 = true;
	
	this.pauseScene = true;
	this.AparenciaDrone = 0;
	
	/* Cilindros do Meio; Cilindros Pontas; Centro; H�lices; Pernas */
	this.droneBlueMetalAppearance = [this.lightBlueMetalDroneAppearance, this.lightBlueMetalDroneAppearance, this.darkBlueMetalDroneAppearance, this.darkBlueMetalDroneAppearance, this.bottomBlackDroneAppearance];
	this.droneDarkWithFrontAppearance = [this.lightMetalDroneAppearance, this.lightMetalDroneAppearance, this.lightMetalWithFrontDroneAppearance, this.darkMetalDroneAppearance, this.bottomBlackDroneAppearance];
	this.droneDarkAppearance = [this.lightMetalDroneAppearance, this.lightMetalDroneAppearance, this.lightMetalDroneAppearance, this.darkMetalDroneAppearance, this.bottomBlackDroneAppearance];
	this.droneRedAppearance = [this.whiteMetalDroneAppearance, this.whiteMetalDroneAppearance, this.redMetalDroneAppearance, this.redMetalDroneAppearance, this.bottomBlackDroneAppearance];
	this.droneGreenAppearance = [this.whiteMetalDroneAppearance, this.whiteMetalDroneAppearance, this.greenTextureDroneAppearance, this.greenTextureDroneAppearance, this.bottomBlackDroneAppearance];
	this.dronePurpleAppearance = [this.greyTextureDroneAppearance, this.greyTextureDroneAppearance, this.greyTextureDroneAppearance, this.blackDroneAppearance, this.bottomBlackDroneAppearance];
	this.droneAppearanceList = [this.droneDarkWithFrontAppearance, this.droneDarkAppearance, this.droneBlueMetalAppearance, this.droneRedAppearance, this.droneGreenAppearance, this.dronePurpleAppearance];
	
	this.speed=8;
};

LightingScene.prototype.initCameras = function()
{
	this.camera = new CGFcamera(0.4, 0.1, 500, vec3.fromValues(30, 30, 30), vec3.fromValues(0, 0, 0));
};

LightingScene.prototype.initLights = function()
{
	this.setGlobalAmbientLight(0.5,0.5,0.5, 1.0);
	
	this.lights[0].setPosition(4, 6, 1, 1);
	this.lights[0].setVisible(true); 
	this.lights[0].setAmbient(0, 0, 0, 1);
	this.lights[0].setDiffuse(1.0, 1.0, 1.0, 1.0);
	this.lights[0].setSpecular( 1, 1, 0, 1.0);
	this.lights[0].enable();
	
	this.lights[1].setPosition(10.5, 6.0, 1.0, 1.0);
	this.lights[1].setVisible(true); 
	this.lights[1].setAmbient(0, 0, 0, 1);
	this.lights[1].setDiffuse(1.0, 1.0, 1.0, 1.0);
	this.lights[1].enable();
	
	this.lights[2].setPosition(10.5, 6.0, 5.0, 1.0);
	this.lights[2].setVisible(true);
	this.lights[2].setSpecular( 1, 1, 1, 1.0);
	this.lights[2].setConstantAttenuation(0);
	this.lights[2].setLinearAttenuation(1);
	this.lights[2].enable();
	
	this.lights[3].setPosition(4, 6.0, 5.0, 1.0);
	this.lights[3].setVisible(true);
	this.lights[3].setConstantAttenuation(0);
	this.lights[3].setQuadraticAttenuation(1);
	this.lights[3].enable();
	
	this.lights[4].setPosition(0.1, 4, 7.5, 1);
	this.lights[4].setVisible(true);
	this.lights[4].setAmbient(0, 0, 0, 1);
	this.lights[4].setDiffuse(1.0, 1.0, 1.0, 1.0);
	this.lights[4].enable();
};

LightingScene.prototype.updateLights = function()
{
	for (var i = 0; i < this.lights.length; i++)
	{
		if(this['luz' + (i + 1)])
			this.lights[i].enable();
		else
			this.lights[i].disable();
		this.lights[i].update();
	}
};

LightingScene.prototype.update = function(currTime)
{
	this.clock.update(currTime, this.pauseScene);
	
	this.updateDroneAppearance();
};

LightingScene.prototype.Pausa = function () {  
	
	this.pauseScene = !this.pauseScene;
};

LightingScene.prototype.updateDroneAppearance = function()
{
	this.drone.updateAppearance(this.AparenciaDrone);
};

LightingScene.prototype.display = function()
{
	this.gl.viewport(0, 0, this.gl.canvas.width, this.gl.canvas.height);
	this.gl.clear(this.gl.COLOR_BUFFER_BIT | this.gl.DEPTH_BUFFER_BIT);

	this.updateProjectionMatrix();
	this.loadIdentity();

	this.applyViewMatrix();
	this.updateLights();
	this.axis.display();
	this.materialDefault.apply();
	
	
	// Floor
	this.floorAppearance.apply();
	
	this.pushMatrix();
		this.translate(7.5, 0, 7.5);
		this.rotate(-90 * degToRad, 1, 0, 0);
		this.scale(15, 15, 0.2);
		this.floor.display();
	this.popMatrix();
	
	

	// Left Wall
	this.windowAppearance.apply();
	
	this.pushMatrix();
		this.translate(0, 4, 7.5);
		this.rotate(90 * degToRad, 0, 1, 0);
		this.scale(15, 8, 0.2);
		this.leftWall.display();
	this.popMatrix();

	// Plane Wall
	this.materialDefault.apply();
	
	this.pushMatrix();
		this.translate(7.5, 4, 0);
		this.scale(15, 8, 0.2);
		this.wall.display();
	this.popMatrix();
	
	// First Table
	this.pushMatrix();
		this.translate(5, 0, 8);
		this.table.display();
	this.popMatrix();

	// Second Table
	this.pushMatrix();
		this.translate(12, 0, 8);
		this.table.display();
	this.popMatrix();

	// Board A
	this.pushMatrix();
		this.translate(4, 4.5, 0.2);
		this.scale(BOARD_WIDTH, BOARD_HEIGHT, 1);
		
		this.slidesAppearance.apply();
		this.boardA.display();
	this.popMatrix();

	// Board B
	this.pushMatrix();
		this.translate(10.5, 4.5, 0.2);
		this.scale(BOARD_WIDTH, BOARD_HEIGHT, 1);
		
		this.boardAppearance.apply();
		this.boardB.display();
	this.popMatrix();
	
	// Circle
	this.pushMatrix();
		this.translate(7.25, 7.2, 0.2);
		this.scale(0.6,0.6,0.2);
		this.clock.display();
	this.popMatrix();
	
	this.materialDefault.apply();
	this.updateDroneAppearance();
	
	// Drone
	this.pushMatrix();
		this.translate(7.5, 4, 7.5);
		//this.rotate(210 * degToRad, 0, 1, 0);
		this.scale(1/2,1/2,1/2);
		this.drone.display();
	this.popMatrix();
	
	
	// ---- END Primitive drawing section
	//ei2023@fe.up.pt
};
